# ============================================================
# EGIS Parameter Sync — Instalador Universal Civil 3D
# Compatible con cualquier PC con Civil 3D 2025/2026
#
# INSTRUCCIONES:
#   1. Copia esta carpeta completa al PC destino:
#      EGISParameterSync_Civil3D.bundle\
#   2. Clic derecho sobre este script → Ejecutar con PowerShell
#   3. Reinicia Civil 3D
# ============================================================

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "  EGIS Parameter Sync — Instalador Universal        " -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""

# ── Paso 1: Copiar bundle a ApplicationPlugins ────────────────
$bundleName = "EGISParameterSync_Civil3D.bundle"
$scriptDir  = Split-Path -Parent $MyInvocation.MyCommand.Path

# El script debe estar junto a la carpeta .bundle
$bundleSrc  = Join-Path $scriptDir $bundleName
$bundleDst  = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\$bundleName"

if (-not (Test-Path $bundleSrc)) {
    # Si el script está DENTRO del bundle
    $bundleSrc = $scriptDir
}

Write-Host "Copiando bundle a ApplicationPlugins..." -ForegroundColor White

New-Item -ItemType Directory -Force -Path $bundleDst | Out-Null
Copy-Item -Path "$bundleSrc\*" -Destination $bundleDst -Recurse -Force
Write-Host "  OK: $bundleDst" -ForegroundColor Green

# ── Paso 2: Verificar que el DLL existe ───────────────────────
$dllPath = Join-Path $bundleDst "Contents\Win64\EGISParameterSync_Civil3D.dll"
if (-not (Test-Path $dllPath)) {
    Write-Host ""
    Write-Host "ERROR: No se encontro el DLL en:" -ForegroundColor Red
    Write-Host "  $dllPath" -ForegroundColor Yellow
    Write-Host "Verifica que la carpeta Contents\Win64\ tiene los archivos." -ForegroundColor White
    Read-Host "Presiona Enter para salir"
    exit 1
}
Write-Host "  OK: DLL verificado" -ForegroundColor Green

# ── Paso 3: Detectar la clave de registro de AutoCAD/Civil 3D ─
Write-Host ""
Write-Host "Detectando instalacion de Civil 3D..." -ForegroundColor White

$acadBaseKey = "HKCU:\Software\Autodesk\AutoCAD"
if (-not (Test-Path $acadBaseKey)) {
    Write-Host "ERROR: No se encontro AutoCAD/Civil 3D instalado en este PC." -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}

# Obtener la version (R25.1, R26.0, etc.)
$versionKey = Get-ChildItem $acadBaseKey | Select-Object -First 1
if (-not $versionKey) {
    Write-Host "ERROR: No se encontro version de AutoCAD en el registro." -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}

$versionPath = $versionKey.PSPath
$versionName = $versionKey.PSChildName
Write-Host "  Version detectada: $versionName" -ForegroundColor Green

# Obtener la subclave del producto (ACAD-XXXX:409)
$productKey = Get-ChildItem $versionPath | 
    Where-Object { $_.PSChildName -like "ACAD-*" } | 
    Select-Object -First 1

if (-not $productKey) {
    Write-Host "ERROR: No se encontro la clave de producto ACAD en el registro." -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}

$productPath = $productKey.PSPath
$productName = $productKey.PSChildName
Write-Host "  Producto detectado: $productName" -ForegroundColor Green

# ── Paso 4: Registrar el plugin en Applications ───────────────
Write-Host ""
Write-Host "Registrando plugin en AutoCAD..." -ForegroundColor White

$appKey = "$productPath\Applications\EGISParameterSync"

try {
    New-Item -Path $appKey -Force | Out-Null
    Set-ItemProperty -Path $appKey -Name "DESCRIPTION" -Value "EGIS Parameter Sync Civil 3D"
    Set-ItemProperty -Path $appKey -Name "LOADCTRLS"   -Value 14   -Type DWord
    Set-ItemProperty -Path $appKey -Name "LOADER"      -Value $dllPath
    Set-ItemProperty -Path $appKey -Name "MANAGED"     -Value 1    -Type DWord
    Write-Host "  OK: Plugin registrado en $appKey" -ForegroundColor Green
}
catch {
    Write-Host "ERROR al registrar el plugin: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Intenta ejecutar PowerShell como Administrador." -ForegroundColor Yellow
    Read-Host "Presiona Enter para salir"
    exit 1
}

# ── Resultado ─────────────────────────────────────────────────
Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "  INSTALACION COMPLETADA                            " -ForegroundColor Green
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Version AutoCAD : $versionName" -ForegroundColor White
Write-Host "  Producto        : $productName" -ForegroundColor White
Write-Host "  DLL             : $dllPath"     -ForegroundColor White
Write-Host ""
Write-Host "Reinicia Civil 3D 2026." -ForegroundColor Yellow
Write-Host "Aparecera la pestana 'EGIS Smart Tools' automaticamente." -ForegroundColor Gray
Write-Host ""
Read-Host "Presiona Enter para cerrar"
