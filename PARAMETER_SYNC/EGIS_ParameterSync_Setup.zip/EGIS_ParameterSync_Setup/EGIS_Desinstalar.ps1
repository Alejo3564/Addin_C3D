# ============================================================
# EGIS Parameter Sync — Desinstalador
# ============================================================

$ErrorActionPreference = "SilentlyContinue"

Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "  EGIS Parameter Sync — Desinstalador               " -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""

# Eliminar del registro
$acadBaseKey = "HKCU:\Software\Autodesk\AutoCAD"
$versionKey  = Get-ChildItem $acadBaseKey | Select-Object -First 1
if ($versionKey) {
    $productKey = Get-ChildItem $versionKey.PSPath | 
        Where-Object { $_.PSChildName -like "ACAD-*" } | 
        Select-Object -First 1
    if ($productKey) {
        $appKey = "$($productKey.PSPath)\Applications\EGISParameterSync"
        if (Test-Path $appKey) {
            Remove-Item -Path $appKey -Recurse -Force
            Write-Host "OK: Plugin eliminado del registro." -ForegroundColor Green
        }
    }
}

# Eliminar carpeta bundle
$bundleDst = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\EGISParameterSync_Civil3D.bundle"
if (Test-Path $bundleDst) {
    Remove-Item -Path $bundleDst -Recurse -Force
    Write-Host "OK: Carpeta bundle eliminada." -ForegroundColor Green
}

Write-Host ""
Write-Host "Desinstalacion completada. Reinicia Civil 3D." -ForegroundColor Yellow
Write-Host ""
Read-Host "Presiona Enter para cerrar"
