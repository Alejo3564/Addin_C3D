# ============================================================
# EGIS Parameter Sync — Instalador Universal Civil 3D
# Compatible con Civil 3D 2025 / 2026
# Clic derecho → Ejecutar con PowerShell
# ============================================================

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "  EGIS Parameter Sync — Instalador Universal        " -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""

# ── Paso 1: Encontrar la carpeta .bundle ──────────────────────
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Buscar cualquier carpeta .bundle en el mismo directorio que el script
$bundleFolder = Get-ChildItem -Path $scriptDir -Filter "*.bundle" -Directory | Select-Object -First 1

if (-not $bundleFolder) {
    Write-Host "ERROR: No se encontro ninguna carpeta .bundle junto al instalador." -ForegroundColor Red
    Write-Host "Asegurate de que el script este en la misma carpeta que *.bundle" -ForegroundColor Yellow
    Write-Host "Carpeta revisada: $scriptDir" -ForegroundColor Gray
    Read-Host "Presiona Enter para salir"
    exit 1
}

$bundleSrc  = $bundleFolder.FullName
$bundleName = "EGISParameterSync_Civil3D.bundle"
$bundleDst  = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\$bundleName"

Write-Host "Bundle encontrado : $($bundleFolder.Name)" -ForegroundColor Gray
Write-Host "Destino           : $bundleDst" -ForegroundColor Gray
Write-Host ""

# ── Paso 2: Copiar bundle a ApplicationPlugins ────────────────
Write-Host "Copiando archivos..." -ForegroundColor White
New-Item -ItemType Directory -Force -Path $bundleDst | Out-Null
Copy-Item -Path "$bundleSrc\*" -Destination $bundleDst -Recurse -Force
Write-Host "  OK: Archivos copiados" -ForegroundColor Green

# ── Paso 3: Verificar DLL ─────────────────────────────────────
$dllPath = Join-Path $bundleDst "Contents\Win64\EGISParameterSync_Civil3D.dll"
if (-not (Test-Path $dllPath)) {
    Write-Host ""
    Write-Host "ERROR: DLL no encontrado en:" -ForegroundColor Red
    Write-Host "  $dllPath" -ForegroundColor Yellow
    Read-Host "Presiona Enter para salir"
    exit 1
}
Write-Host "  OK: DLL verificado" -ForegroundColor Green

# ── Paso 4: Detectar registro de AutoCAD/Civil 3D ────────────
Write-Host ""
Write-Host "Detectando Civil 3D..." -ForegroundColor White

$acadBaseKey = "HKCU:\Software\Autodesk\AutoCAD"
if (-not (Test-Path $acadBaseKey)) {
    Write-Host "ERROR: AutoCAD/Civil 3D no encontrado en este PC." -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}

# Tomar la primera versión encontrada (R25.1, R26.0, etc.)
$versionKey = Get-ChildItem $acadBaseKey | Select-Object -First 1
if (-not $versionKey) {
    Write-Host "ERROR: No se encontro version de AutoCAD." -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}

$versionName = $versionKey.PSChildName
Write-Host "  Version : $versionName" -ForegroundColor Green

# Tomar la primera subclave ACAD-XXXX:XXX
$productKey = Get-ChildItem $versionKey.PSPath |
    Where-Object { $_.PSChildName -like "ACAD-*" } |
    Select-Object -First 1

if (-not $productKey) {
    Write-Host "ERROR: No se encontro la clave de producto." -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}

$productName = $productKey.PSChildName
Write-Host "  Producto: $productName" -ForegroundColor Green

# ── Paso 5: Registrar plugin ──────────────────────────────────
Write-Host ""
Write-Host "Registrando plugin..." -ForegroundColor White

$appKey = "$($productKey.PSPath)\Applications\EGISParameterSync"

try {
    New-Item -Path $appKey -Force | Out-Null
    Set-ItemProperty -Path $appKey -Name "DESCRIPTION" -Value "EGIS Parameter Sync Civil 3D"
    Set-ItemProperty -Path $appKey -Name "LOADCTRLS"   -Value 14  -Type DWord
    Set-ItemProperty -Path $appKey -Name "LOADER"      -Value $dllPath
    Set-ItemProperty -Path $appKey -Name "MANAGED"     -Value 1   -Type DWord
    Write-Host "  OK: Plugin registrado correctamente" -ForegroundColor Green
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Intenta ejecutar PowerShell como Administrador." -ForegroundColor Yellow
    Read-Host "Presiona Enter para salir"
    exit 1
}

# ── Listo ─────────────────────────────────────────────────────
Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "  INSTALACION COMPLETADA                            " -ForegroundColor Green
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  AutoCAD  : $versionName"  -ForegroundColor White
Write-Host "  Producto : $productName"  -ForegroundColor White
Write-Host "  DLL      : $dllPath"      -ForegroundColor White
Write-Host ""
Write-Host "Reinicia Civil 3D." -ForegroundColor Yellow
Write-Host "Aparecera la pestana 'EGIS Smart Tools' en la ribbon." -ForegroundColor Gray
Write-Host ""
Read-Host "Presiona Enter para cerrar"
